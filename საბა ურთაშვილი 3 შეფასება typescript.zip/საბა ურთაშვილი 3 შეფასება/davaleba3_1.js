var user = {
    name: "Nika",
    age: 25,
    id: 101,
    department: "IT"
};
console.log(user);

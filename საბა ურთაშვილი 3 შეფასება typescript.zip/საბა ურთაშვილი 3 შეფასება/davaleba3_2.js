var user2 = {
    name: "toma",
    age: 4,
    salami: function () {
        return "\u10DB\u10DD\u10D2\u10D4\u10E1\u10D0\u10DA\u10DB\u10D4\u10D1\u10D8\u10D7, \u10DB\u10D4 \u10D5\u10D0\u10E0 ".concat(this.name);
    }
};
console.log(user2.salami());

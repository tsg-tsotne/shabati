var info = {
    name1: "saba",
    name2: "giorgi",
    age: 17,
    code: 555,
    position: "მოსწავლე",
    tel: "555-123456",
    car: "mercedes metris"
};
console.log(info.tel, info.car);

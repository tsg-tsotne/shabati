var productItem = {
    price: 2500
};
console.log(productItem.price);
